﻿using Newtonsoft.Json.Linq;

public class JsonReferenceResolver
{
    private Dictionary<string, JObject> resolvedReferences = new Dictionary<string, JObject>();

    public T Deserialize<T>(string json)
    {
        JObject parsedObject = JObject.Parse(json);
        ResolveReferences(parsedObject);
        return parsedObject.ToObject<T>();
    }

    private void ResolveReferences(JObject jsonObject)
    {
        JToken references;
        if (jsonObject.TryGetValue("$ref", StringComparison.OrdinalIgnoreCase, out references))
        {
            string referencePath = references.Value<string>();
            if (!resolvedReferences.ContainsKey(referencePath))
            {
                // Load the referenced JSON file
                string referencedJson = File.ReadAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory.Replace("\\bin\\Debug\\net6.0\\", "\\Schema\\"), referencePath.Replace("#", string.Empty)));

                // Parse the referenced JSON and store it
                JObject referencedObject = JObject.Parse(referencedJson);
                resolvedReferences.Add(referencePath, referencedObject);

                // Recursively resolve references in the referenced object
                //ResolveReferences(referencedObject);
            }

            // Replace the reference with the resolved object
            JToken resolvedObject = resolvedReferences[referencePath];
            jsonObject.Replace(resolvedObject);
        }

        foreach (JProperty property in jsonObject.Properties())
        {
            if (property.Value.Type == JTokenType.Object)
            { 
                ResolveReferences((JObject)property.Value);
            }
            else if (property.Value.Type == JTokenType.Array) 
            {
                var array = (JArray)property.Value;
                for (int index = 0; index< array.Count; index++) 
                {
                    var item = array[index];
                    ResolveReferences((JObject)item);
                }               
            }
        }
    }
}
