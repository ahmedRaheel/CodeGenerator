﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace CodeGeneration
{
    public class ClassDetails
    {
        [JsonProperty("className")]
        public string ClassName { get; set; }

        [JsonProperty("accessModifier")]
        public string AccessModifier { get; set; }

        [JsonProperty("baseClass")]
        public string BaseClass { get; set; }

        [JsonProperty("interface")]
        public List<string> Interface { get; set; }

        [JsonProperty("properties")]
        public List<PropertyDefinition> Properties { get; set; }
    }
}
