﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace CodeGeneration
{
    public class ParentModel
    {
        [JsonProperty("createSolution")]
        public bool CreateSolution { get; set; }

        [JsonProperty("newProject")]
        public bool NewProject { get; set; }

        [JsonProperty("entities")]
        public List<GenerationModel> Entities { get; set; }
        [JsonProperty("enums")]
        public List<GenerationModel> Enums { get; set; }

    }
}
