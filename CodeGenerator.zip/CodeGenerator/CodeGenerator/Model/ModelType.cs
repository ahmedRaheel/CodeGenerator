﻿namespace CodeGeneration
{
    public enum ModelType 
    {
        Class, 
        Interface, 
        Enum, 
        BaseClass,
        InheritedClass, 
        AbstractClass,
        ChildEntity, 
        ParentEntity,
        DTO,
        GenenicClass, 
        GenericDriveClass, 
        GenericDriveInterface,
        GenericInterface
    }
}
