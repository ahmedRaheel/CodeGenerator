﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace CodeGeneration
{
    public class GenerationModel
    {
        [JsonProperty("modeltype")]
        public ModelType ModelType { get; set; }

        [JsonProperty("namespace")]
        public string Namespace { get; set; }

        [JsonProperty("usings")]
        public List<string> Usings { get; set; }

        [JsonProperty("enum")]
        public EnumDetails EnumDetails { get; set; }

        [JsonProperty("class")]
        public ClassDetails ClassDetails { get; set; }

        [JsonProperty("FileName")]
        public string FileName { get; set; }

        [JsonProperty("Folder")]
        public string Folder { get; set; }
    }
}
