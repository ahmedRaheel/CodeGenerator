﻿using Newtonsoft.Json;

namespace CodeGeneration
{
    public class PropertyDefinition
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("nullable")]
        public bool Nullable { get; set; }

        [JsonProperty("accessModifier")]
        public string AccessModifier { get; set; }

        [JsonProperty("defaultValue")]
        public string DefaultValue { get; set; }
    }
}
