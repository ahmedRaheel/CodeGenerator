﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace CodeGeneration
{
    public class EnumDetails
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("accessModifier")]
        public string AccessModifier { get; set; }

        [JsonProperty("baseClass")]
        public string BaseClass { get; set; }

        [JsonProperty("values")]
        public List<string> Values { get; set; }
    }
}
